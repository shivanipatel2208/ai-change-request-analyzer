@echo off
title Backend - AI Change Request Analyzer
cd /d "%~dp0backend"
echo Starting backend server (http://localhost:8000)...
echo Keep this window open. Close it to stop the backend.
echo.
python -m uvicorn app.main:app --reload
echo.
echo Backend stopped or failed to start. See any error above.
pause
