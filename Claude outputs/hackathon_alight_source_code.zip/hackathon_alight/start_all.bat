@echo off
echo ============================================
echo   Starting AI Change Request Analyzer
echo ============================================
echo.
echo Opening backend and frontend in separate windows...
echo.
start "Backend - AI Change Request Analyzer" cmd /k "cd /d %~dp0backend && python -m uvicorn app.main:app --reload"
timeout /t 3 /nobreak >nul
start "Frontend - AI Change Request Analyzer" cmd /k "cd /d %~dp0frontend && npm run dev"
echo.
echo Both servers are starting now, each in its own window:
echo   Backend:  http://localhost:8000
echo   Frontend: http://localhost:5173
echo.
echo IMPORTANT: Keep those two new windows open while you use the app.
echo Closing a window stops that server. This window can be closed now.
echo.
pause
