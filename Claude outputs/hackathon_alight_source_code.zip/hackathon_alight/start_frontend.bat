@echo off
title Frontend - AI Change Request Analyzer
cd /d "%~dp0frontend"
echo Starting frontend server (http://localhost:5173)...
echo Keep this window open. Close it to stop the frontend.
echo.
npm run dev
echo.
echo Frontend stopped or failed to start. See any error above.
pause
